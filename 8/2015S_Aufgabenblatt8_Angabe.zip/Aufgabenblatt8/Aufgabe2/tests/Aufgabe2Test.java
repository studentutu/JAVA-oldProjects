import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

public class Aufgabe2Test {

    @Rule
    public Timeout globalTimeout = new Timeout(100);

    @Test
    public void testFoo() throws Exception {

    }
}