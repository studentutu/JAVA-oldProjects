import org.junit.Rule;
import org.junit.Test;

import org.junit.rules.Timeout;

public class Aufgabe3Test {

    @Rule
    public Timeout globalTimeout = new Timeout(100);

    @Test
    public void testSortedIntArray() throws Exception {

    }
}