/*
    Aufgabe5) Java Allgemein

    Als Wiederholung, nennen Sie die Ihrer Meinung nach 5 wichtigsten Themenbereiche im Zusammenhang mit der
    Programmierung in Java und beschreiben Sie diese Themenbereiche kurz (in jeweils 1 bis 3 Sätzen).
    In der Übung wird über das eine oder andere Thema kurz diskutiert.

    Bei dieser Aufgabe gibt es keine Testfälle. Aus einem erfolgreichen Durchlauf der Testklasse folgt also
    nicht automatisch die Korrektheit der Lösung.

*/

public class Aufgabe5 {

    // just for testing ...
    public static void main(String[] args) {
        // Implementierung von main wird nicht beurteilt
    }
}