import org.junit.Test;

public class Aufgabe1Test {

    @Test
    public void test() throws Exception {
    }

}

