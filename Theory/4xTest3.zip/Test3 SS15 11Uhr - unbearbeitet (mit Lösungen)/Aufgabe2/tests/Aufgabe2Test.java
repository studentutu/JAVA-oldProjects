import org.junit.Test;

public class Aufgabe2Test {
}
