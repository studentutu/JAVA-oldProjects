import org.junit.Test;

public class Aufgabe3Test {

}

