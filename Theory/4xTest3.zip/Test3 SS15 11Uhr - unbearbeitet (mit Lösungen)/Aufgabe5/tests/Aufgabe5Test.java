import org.junit.Test;

public class Aufgabe5Test {
}
