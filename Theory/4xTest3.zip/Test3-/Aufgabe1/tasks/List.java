/***********************************************************************************
BEURTEILUNG von 1227008 für Aufgabe 1: 14 Punkte

    insert:   0 - Hilfsmethode nicht private (0p) Node nicht hinzugefügt bei insert, wenn Liste head null (2p) Element an zweiter Stelle eingefügt, Rest der Liste wird überschrieben (3p) Zugriff auf Variablen von node nur durch getter (0p)
    remove:   5 -  
    get:      3 - fehlende Überprüfung ob Knoten null ist -> mögliche nullpointerexception (1p) Index off by 1 (1p)
    copy:     1 - gibt this zurück, keine Kopie (4p)
    toString: 0 - FEHLT
    main:     5 -

Hier ist ein Beispiel für die wesentlichen Teile einer Lösung:

    class Node {
        ...

        private Node(String elem, Node next) {
            this.elem = elem;
            this.next = next;
        }

        private Node copy() {
            return new Node(elem, next == null ? null : next.copy());
        }

        public String toString() {
            if (next != null) {
                return next + " " + elem;
            }
            return elem;
        }

    }

    ...

    public void insert(String elem) {
        if (head == null) {
            head = new Node(elem, null);
        }
        else {
            Node node = head;
            while (node.next != null) {
                node = node.next;
            }
            node.next = new Node(elem, null);
        }
    }

    public String remove() {
        if (head == null) {
            return null;
        }
        String result = head.elem;
        head = head.next;
        return result;
    }

    public String get(int n) {
        if (n < 0 || head == null) {
            return null;
        }
        Node node = head;
        while (--n >= 0) {
            node = node.next;
            if (node == null) {
                return null;
            }
        }
        return node.elem;
    }

    public List copy() {
        List result = new List();
        if (this.head != null) {
            result.head = this.head.copy();
        }
        return result;
    }

    @Override
    public String toString() {
        if (head == null) {
            return "";
        }
        return head.toString();
    }

    public static void main(String[] args) {
        List list1 = new List();
        list1.insert("d");
        list1.insert("c");
        list1.insert("b");
        list1.insert("a");
        System.out.println(list1);
        System.out.println(list1.remove());
        System.out.println(list1);
        List list2 = list1.copy();
        System.out.println(list1.get(2));
        System.out.println(list2.get(3));
    }

***********************************************************************************/
/***********************************************************************************
BEURTEILUNG von 1227008 für Aufgabe 1: 14 Punkte

    insert:   0 - Hilfsmethode nicht private (0p) Node nicht hinzugefügt bei insert, wenn Liste head null (2p) Element an zweiter Stelle eingefügt, Rest der Liste wird überschrieben (3p) Zugriff auf Variablen von node nur durch getter (0p)
    remove:   5 -  
    get:      3 - fehlende Überprüfung ob Knoten null ist -> mögliche nullpointerexception (1p) Index off by 1 (1p)
    copy:     1 - gibt this zurück, keine Kopie (4p)
    toString: 0 - FEHLT
    main:     5 -

Hier ist ein Beispiel für die wesentlichen Teile einer Lösung:

    class Node {
        ...

        private Node(String elem, Node next) {
            this.elem = elem;
            this.next = next;
        }

        private Node copy() {
            return new Node(elem, next == null ? null : next.copy());
        }

        public String toString() {
            if (next != null) {
                return next + " " + elem;
            }
            return elem;
        }

    }

    ...

    public void insert(String elem) {
        if (head == null) {
            head = new Node(elem, null);
        }
        else {
            Node node = head;
            while (node.next != null) {
                node = node.next;
            }
            node.next = new Node(elem, null);
        }
    }

    public String remove() {
        if (head == null) {
            return null;
        }
        String result = head.elem;
        head = head.next;
        return result;
    }

    public String get(int n) {
        if (n < 0 || head == null) {
            return null;
        }
        Node node = head;
        while (--n >= 0) {
            node = node.next;
            if (node == null) {
                return null;
            }
        }
        return node.elem;
    }

    public List copy() {
        List result = new List();
        if (this.head != null) {
            result.head = this.head.copy();
        }
        return result;
    }

    @Override
    public String toString() {
        if (head == null) {
            return "";
        }
        return head.toString();
    }

    public static void main(String[] args) {
        List list1 = new List();
        list1.insert("d");
        list1.insert("c");
        list1.insert("b");
        list1.insert("a");
        System.out.println(list1);
        System.out.println(list1.remove());
        System.out.println(list1);
        List list2 = list1.copy();
        System.out.println(list1.get(2));
        System.out.println(list2.get(3));
    }

***********************************************************************************/
/*
Lesen Sie die Aufgaben genau durch.
Verändern Sie die in den Aufgaben beschriebenen Programmstellen.
Verändern Sie aber nicht vorgegebene Methodenköpfe oder andere vorgegebene Programmteile!

Achtung: Vorgegebene Testfälle überprüfen nur die Syntax. Sie überprüfen nicht die Korrektheit der Lösungen.
*/
public class List {

    /*
    Aufgabe:
        Objekte der Klasse List stellen verkettete Listen von Strings mit Knoten vom Typ Node dar.
        Ergänzen Sie fehlende Teile entsprechend den Kommentaren an den mit TODO: gekennzeichneten Stellen.

    Punkte (maximal 30):
        5 Punkte für insert,
        5 Punkte für remove,
        5 Punkte für get;
        5 Punkte für copy;
        5 Punkte für toString,
        5 Punkte für main.
        Auch für teilweise korrekte Lösungen werden Punkte vergeben.
    */

    class Node {

        // Do not change the object variables.  Do not add further object variables.
        private String elem;
        private Node next;

        // TODO: Define here constructors and methods of Node (if needed).

        public Node(String elem) {
            this.elem = elem;
            this.next = null;
        }

        public Node(String elem, Node next) {
            this.elem = elem;
            this.next = next;
        }

        public String getElem() {
            return elem;
        }

        public Node getNext() {
            return next;
        }

        public void add(Node next) {
            this.next = next;
        }
    } // End of the definition of Node


    // Initially the list is empty.
    private Node head = null;


    // Adds a string as last element to the list.
    public void insert(String elem) {
        // TODO: Implementation is your task
        if(head != null) {
            if(head.getNext() != null) {
                Node nextNode = head.getNext();
                while (nextNode != null) {
                    if (nextNode.getNext() == null) {
                        head.add(new Node(elem));
                    }
                    nextNode = nextNode.getNext();
                }
            }
            else {
                head.add(new Node(elem));
            }
        }
    }


    // Removes and returns the element in the head of the list;  the result is null if the list is empty;
    // 'insert' and 'remove' together show FIFO behavior.
    public String remove() {
        // TODO: Implementation is your task
        if(head == null)
            return null;

        Node tmp = head.getNext();
        String first = head.getElem();
        head = tmp;
        return first;
    }


    // Returns the n-th element of the list;  if n == 0, the element in the head of the list is returned;
    // null is returned if n < 0 or the list does not have enough elements;  'this' remains unchanged.
    public String get(int n) {
        // TODO: Implementation is your task
        if(n == 0)
            return head.getElem();

        if(n < 0)
            return null;

        Node newHead = head.getNext();
        String nthElement = "";
        while(n > 0) {
            if(newHead.getNext() == null && n > 1)
                return null;
            else {
                nthElement = newHead.getElem();
                newHead = newHead.getNext();
                n-= 1;
            }
        }

        return nthElement;
    }


    // Returns a new list containing the same elements as 'this' in the same order;  'this' remains unchanged.
    // Do not use clone().
    public List copy() {
        // TODO: Implementation is your task
        return this;
    }


    // Returns a string containing the elements (separated by the space character ' ') in reverse order;
    // for example, if the list contains "x" (as first element), "y" and "z" (as last element), then toString()
    // returns "z y x";  for an empty list the result is the empty string "".
    @Override
    public String toString() {
        // TODO: Implementation is your task
        /*String s = head.getElem();
        if(head.getNext() != null) {
            s+= " " + head.getNext().toString();
        }*/
        return "";
    }


    // TODO: Complete main as in the TODO comments.
    public static void main(String[] args) {
        List list1 = new List();
        // TODO: Call 'insert' 4 times such that ...
        list1.insert("d");
        list1.insert("c");
        list1.insert("b");
        list1.insert("a");
        System.out.println(list1);  // TODO: ... this statement prints: "a b c d"

        // TODO: Call 'remove' on 'list1' and print a line with the result.
        System.out.println(list1.remove());
        // TODO: Print another line with the content of 'list1'.
        System.out.println(list1.toString());
        // TODO: Create a new list 'list2' by calling 'copy' on 'list1'.
        List list2 = list1.copy();
        // TODO: Call 'get(2)' on 'list1' and print a line with the result.
        System.out.println(list1.get(2));
        // TODO: Call 'get(3)' on 'list2' and print a line with the result.
        System.out.println(list2.get(3));

    }

}

class Test {
    public static void main(String[] args) {
        List l = new List();
    }
}

