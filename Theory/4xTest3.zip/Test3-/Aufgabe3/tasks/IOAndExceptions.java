/***********************************************************************************
BEURTEILUNG von 1227008 für Aufgabe 3: 9 Punkte

    longestLine:   6 - File nicht immer geschlossen, Output nicht auf Standardfehlerausgabe
    maxLineLength: 3 - File doppelt gelesen
    main:          0 - zu unvollständig

Hier ist ein Beispiel für die wesentlichen Teile einer Lösung:

    public static String longestLine(String filePath) {
        String longest = "";
        try {
            BufferedReader in = null;
            try {
                in = new BufferedReader(new FileReader(filePath));
                String s;
                while ((s = in.readLine()) != null) {
                    if (s.length() > longest.length()) {
                        longest = s;
                    }
                }
            }
            finally {
                if (in != null) {
                    in.close();
                }
            }
        }
        catch (IOException x) {
            System.err.println("read error");
            longest = null;
        }
        return longest;
    }

    public static void maxLineLength(String filePath) {
        String s = longestLine(filePath);
        System.out.println(filePath + ": " + (s == null ? "null" : s.length()));
    }

    public static void main(String[] args) {
        for (String s : args) {
            maxLineLength(s);
        }
    }

***********************************************************************************/
/***********************************************************************************
BEURTEILUNG von 1227008 für Aufgabe 3: 9 Punkte

    longestLine:   6 - File nicht immer geschlossen, Output nicht auf Standardfehlerausgabe
    maxLineLength: 3 - File doppelt gelesen
    main:          0 - zu unvollständig

Hier ist ein Beispiel für die wesentlichen Teile einer Lösung:

    public static String longestLine(String filePath) {
        String longest = "";
        try {
            BufferedReader in = null;
            try {
                in = new BufferedReader(new FileReader(filePath));
                String s;
                while ((s = in.readLine()) != null) {
                    if (s.length() > longest.length()) {
                        longest = s;
                    }
                }
            }
            finally {
                if (in != null) {
                    in.close();
                }
            }
        }
        catch (IOException x) {
            System.err.println("read error");
            longest = null;
        }
        return longest;
    }

    public static void maxLineLength(String filePath) {
        String s = longestLine(filePath);
        System.out.println(filePath + ": " + (s == null ? "null" : s.length()));
    }

    public static void main(String[] args) {
        for (String s : args) {
            maxLineLength(s);
        }
    }

***********************************************************************************/
import java.io.*;

public class IOAndExceptions {

    /*
    Aufgabe:
        Ergänzen Sie fehlende Teile der Methoden entsprechend den Kommentaren an den mit TODO gekennzeichneten Stellen.

    Punkte (maximal 15):
        9 Punkte für longestLine,
        3 Punkte für maxLineLength,
        3 Punkte für main.
        Auch für teilweise korrekte Lösungen werden Punkte vergeben.
    */

    // Returns the longest line in the file filePath (has to be opened for reading);
    // if there are several lines of the same size, the first one is selected;
    // on return the file is closed;  if the file does not exist or cannot be read, the string "read error" is written
    // to the standard error stream (Standardfehlerausgabe) and null is returned.
    public static String longestLine(String filePath) {
        // TODO: Implementation is your task
        // Note: You have to open and close the file and handle exceptions related to I/O errors.
        BufferedReader in = null;

        String longest = "";

        try {
            in = new BufferedReader(new FileReader(filePath));

            String line;

            while((line = in.readLine()) != null) {
                if(line.length() > longest.length())
                    longest = line;
            }
            in.close();
        } catch (IOException ioe) {
            System.out.println("read error");
            return null;
        }
        return longest;
    }


    // Prints a line of the following form to the standard output stream (Standardausgabe):
    //     <filePath>: <length-of-line>
    // <filePath> is the content of the parameter, and <length-of-line> is the length of the longest line in the
    // file determined by filePath;  <length-of-line> is null if a corresponding call of longestLine returns null.
    public static void maxLineLength(String filePath) {
        // TODO: Implementation is your task
        if(longestLine(filePath) != null)
            System.out.println(filePath + ": " + longestLine(filePath).length());
        else
            System.out.println(filePath + ": " + null);

    }

    // Calls maxLineLength once for each command line argument (Programmparameter);
    // each command line argument is assumed to specify the name or path of a file.
    public static void main(String[] args) {
        // TODO: Implementation is your task
        maxLineLength("Testfile");
    }

}

