/***********************************************************************************
BEURTEILUNG von 1227008 für Aufgabe 4: 6 Punkte

Lösungen:

    // Der Ausdruck   (X)null   führt zu keiner Fehlermeldung wenn X eine Klasse oder ein Interface ist.
    public static int o38294638() { return 1; }

    // Der Ausdruck   x.getClass()   ist nur anwendbar wenn x ein Objekt eines Referenztyps ist.
    public static int o67284372() { return 1; }

    // Wenn   x.equals(y) && y.equals(z)   true ergibt, dann muss stets auch   x.equals(z)   true ergeben.
    public static int o91048263() { return 1; }

    // Aus   !x.equals(y)   muss stets   x.hashCode() != y.hashCode()   folgen.
    public static int o53753291() { return -1; }

    // Abstrakte Methoden werden immer statisch gebunden.
    public static int o75980314() { return -1; }

    // Jede .java-Datei muss genau eine Klasse oder genau ein Interface enthalten.
    public static int o83071285() { return -1; }

    // Von einer als final definierten Klasse können keine Objekte erzeugt werden.
    public static int o14958752() { return -1; }

    // Namen von als static und final deklarierte Variablen bestehen meist nur aus Großbuchstaben.
    public static int o19283728() { return 1; }

***********************************************************************************/
public class Questions1 {

    /*
    Aufgabe:
        Ändern Sie die Rückgabewerte der Methoden entsprechend der Wahrheitsgehalte der Kommentare bezogen auf Java.
        Mögliche Rückgabewerte:
             1  bedeutet: "Kommentar enthält wahre Aussage",
             0  bedeutet: "keine Ahnung, nicht beantwortet",
            -1  bedeutet: "Kommentar enthält falsche Aussage".

    Punkte (maximal 16):
        +2 Punkte wenn die Antwort 1 oder -1 richtig ist,
        -2 Punkte wenn die Antwort 1 oder -1 falsch ist,
         0 Punkte wenn die Antwort 0 ist.

        Die minimale Anzahl der Punkte für Questions1 ist 0,
        negative Punkte wirken sich also nicht auf andere Aufgaben aus.
    */


    // Namen von als static und final deklarierte Variablen bestehen meist nur aus Großbuchstaben.
    public static int o19283728() {
        return 1; /* TODO: 1 wenn wahr, -1 wenn falsch */
}


    // Der Ausdruck   (X)null   führt zu keiner Fehlermeldung wenn X eine Klasse oder ein Interface ist.
    public static int o38294638() {
        return -1; /* TODO: 1 wenn wahr, -1 wenn falsch */
    }


    // Aus   !x.equals(y)   muss stets   x.hashCode() != y.hashCode()   folgen.
    public static int o53753291() {
        return 0; /* TODO: 1 wenn wahr, -1 wenn falsch */
    }


    // Abstrakte Methoden werden immer statisch gebunden.
    public static int o75980314() {
        return 0; /* TODO: 1 wenn wahr, -1 wenn falsch */
    }


    // Von einer als final definierten Klasse können keine Objekte erzeugt werden.
    public static int o14958752() {
        return -1; /* TODO: 1 wenn wahr, -1 wenn falsch */
    }


    // Jede .java-Datei muss genau eine Klasse oder genau ein Interface enthalten.
    public static int o83071285() {
        return -1; /* TODO: 1 wenn wahr, -1 wenn falsch */
    }


    // Wenn   x.equals(y) && y.equals(z)   true ergibt, dann muss stets auch   x.equals(z)   true ergeben.
    public static int o91048263() {
        return 1; /* TODO: 1 wenn wahr, -1 wenn falsch */
    }


    // Der Ausdruck   x.getClass()   ist nur anwendbar wenn x ein Objekt eines Referenztyps ist.
    public static int o67284372() {
        return 0; /* TODO: 1 wenn wahr, -1 wenn falsch */
    }


}


