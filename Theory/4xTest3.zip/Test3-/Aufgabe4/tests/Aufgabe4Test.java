import org.junit.Test;

public class Aufgabe4Test {
}

