/***********************************************************************************
 Lösungen:

 // Exceptions vom Typ IOException müssen in throws-Klauseln angegeben werden (falls sie nicht abgefangen werden).
 public static int o38294638() { return 1; }

 // Der Client muss dafür sorgen, dass Invarianten am Anfang und Ende jeder Methodenausführung eingehalten sind.
 public static int o67284372() { return -1; }

 // Der Client darf davon ausgehen, dass Nachbedingungen am Ende einer Methodenausführung eingehalten sind.
 public static int o91048263() { return 1; }

 // "Design-by-Contract" bietet die Grundlage für die Zusammenarbeit zwischen Softwareentwickler und Auftraggeber.
 public static int o53753291() { return -1; }

 // Schleifeninvarianten stehen meist in den Kommentaren ganz zu Beginn einer Klassendefinition.
 public static int o19283728() { return -1; }

 // Nachbedingungen einer Methode sind im Untertyp gleich oder stärker als im Obertyp.
 public static int o75980314() { return 1; }

 // Die Anzahl der im Programm gefundenen Fehler ist oft direkt proportional zur Anzahl der vorhandenen Fehler.
 public static int o83071285() { return 1; }

 ***********************************************************************************/
public class Questions32 {

    /*
    Aufgabe:
        Ändern Sie die Rückgabewerte der Methoden entsprechend der Wahrheitsgehalte der Kommentare bezogen auf Java.
        Mögliche Rückgabewerte:
             1  bedeutet: "Kommentar enthält wahre Aussage",
             0  bedeutet: "keine Ahnung, nicht beantwortet",
            -1  bedeutet: "Kommentar enthält falsche Aussage".

    Punkte (maximal 14):
        +2 Punkte wenn die Antwort 1 oder -1 richtig ist,
        -2 Punkte wenn die Antwort 1 oder -1 falsch ist,
         0 Punkte wenn die Antwort 0 ist.

        Die minimale Anzahl der Punkte für Questions2 ist 0,
        negative Punkte wirken sich also nicht auf andere Aufgaben aus.
    */


    // Der Client darf davon ausgehen, dass Nachbedingungen am Ende einer Methodenausführung eingehalten sind.
    public static int o91048263() {
        return 0; /* TODO: 1 wenn wahr, -1 wenn falsch */
    }


    // Der Client muss dafür sorgen, dass Invarianten am Anfang und Ende jeder Methodenausführung eingehalten sind.
    public static int o67284372() {
        return 0; /* TODO: 1 wenn wahr, -1 wenn falsch */
    }


    // Exceptions vom Typ IOException müssen in throws-Klauseln angegeben werden (falls sie nicht abgefangen werden).
    public static int o38294638() {
        return 0; /* TODO: 1 wenn wahr, -1 wenn falsch */
    }


    // Schleifeninvarianten stehen meist in den Kommentaren ganz zu Beginn einer Klassendefinition.
    public static int o19283728() {
        return 0; /* TODO: 1 wenn wahr, -1 wenn falsch */
    }


    // Die Anzahl der im Programm gefundenen Fehler ist oft direkt proportional zur Anzahl der vorhandenen Fehler.
    public static int o83071285() {
        return 0; /* TODO: 1 wenn wahr, -1 wenn falsch */
    }


    // Nachbedingungen einer Methode sind im Untertyp gleich oder stärker als im Obertyp.
    public static int o75980314() {
        return 0; /* TODO: 1 wenn wahr, -1 wenn falsch */
    }


    // "Design-by-Contract" bietet die Grundlage für die Zusammenarbeit zwischen Softwareentwickler und Auftraggeber.
    public static int o53753291() {
        return 0; /* TODO: 1 wenn wahr, -1 wenn falsch */
    }
    //falsch -1


}


