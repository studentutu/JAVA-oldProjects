package Do15;

/**
 * Created by Heraldo on 27.05.2015.
 */
public class Binary {

    private final String value;

    public Binary(int val) {
        value = toBinary(val);
    }

    public int getDecimal() { return toDecimal(value.length() - 1, 0); }

    public String getValue() {
        return value;
    }

    public Binary addBinaries(Binary other) {
        int dec1 = this.getDecimal();
        int dec2 = other.getDecimal();

        return new Binary(dec1 + dec2);
    }

    @Override
    public String toString() { return String.format("Binary: %s; Decimal: %d", value, getDecimal()); }

    @Override
    public boolean equals(Object o) {
        if(this == o)
            return true;

        if(o instanceof Binary) {
            Binary b = (Binary) o;

            return value.equals((b.value));
        }

        return false;
    }

    private int toDecimal(final int index, final int pow) {
        if(index < 0)
            return 0;

        int val = Integer.parseInt(String.valueOf(value.charAt(index)));
        int result = (int)Math.pow(2, pow) * val;

        return result + toDecimal(index - 1, pow + 1);
    }

    private String toBinary(final int val) {
        if(val <= 0)
            return "0";

        int rest = val % 2;
        return toBinary(val / 2) + rest;
    }
}
