package Do15;

/**
 * Created by Heraldo on 28.05.2015.
 */
public class Main {

    public static void main(String[] args) {
        Tester.startTestingAll();
    }
}
