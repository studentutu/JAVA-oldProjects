package Do15;

/**
 * Created by Heraldo on 28.05.2015.
 */
public class SearchTree {

    private Node root;

    public boolean isEmpty() { return root == null; }

    public int size() {
        if(isEmpty())
            return 0;

        return root.size();
    }

    public void add(Binary bin) {
        if(isEmpty())
            root = new Node(bin);
        else if(0 < bin.getDecimal())
            root.add(bin);
    }

    public boolean contains(Binary bin) {
        if(isEmpty())
            return false;

        return root.contains(bin);
    }

    public int height() {
        if(isEmpty())
            return -1;

        return root.height(0);
    }

    public String toString() {
        if(isEmpty())
            return "Empty Tree";

        return root.toString("Root", 0);
    }

    public boolean equals(Object o) {
        if(o == this)
            return true;

        if(o instanceof SearchTree) {

            SearchTree st = (SearchTree) o;
            if (this.isEmpty() || st.isEmpty())
                return this.isEmpty() && st.isEmpty();

            if(this.size() != st.size())
                return false;

            return this.root.equals(st.root);

        }

        return false;
    }

    private class Node {
        private Node left;
        private Node right;
        private Binary value;

        private Node(Binary val) {
            value = val;
            left = right = null;
        }

        private int size() {
            int size = 1;

            if(this.left != null)
                size += this.left.size();
            if(this.right != null)
                size += this.right.size();

            return size;
        }

        private void add(final Binary bin) {
            if(bin.getDecimal() < value.getDecimal()) {
                if(this.left == null)
                    this.left = new Node(bin);
                else
                    this.left.add(bin);
            }
            else if(value.getDecimal() < bin.getDecimal()) {
                if(this.right == null)
                    this.right = new Node(bin);
                else
                    this.right.add(bin);
            }
        }

        private boolean contains(final Binary bin) {
            if(value.equals(bin))
                return true;

            if(left != null && bin.getDecimal() < value.getDecimal())
                return left.contains(bin);

            if(right != null && value.getDecimal() < bin.getDecimal())
                return right.contains(bin);

            return false;
        }

        private int height(final int h) {
            int leftH = left != null? left.height(h + 1) : h;
            int rightH = right != null? right.height(h + 1) : h;

            return Math.max(leftH, rightH);
        }

        private String toString(final String name, final int level) {
            String output = "";

            for(int  i = 0; i < level * 2; i++)
                output += " ";

            output += String.format("%d. Ebene. %s value: %s\n", level, name, value.toString());

            if(this.left != null)
                output += left.toString("Left", level + 1);
            if(this.right != null)
                output += right.toString("Right", level + 1);

            return output;
        }

        public boolean equals(Object o) {
            if(this == o)
                return true;

            if(o instanceof Node) {
                Node n = (Node) o;

                if(!this.value.equals(n.value))
                    return false;

                boolean equals = true;
                if(this.left != null)
                    equals = equals && this.left.equals(n.left);
                else if(n.left != null)
                    return false;

                // if equals already false, so ignore right
                if(!equals) {
                    if (this.right != null)
                        equals = equals && this.right.equals(n.right);
                    else if (n.right != null)
                        return false;
                }
                return equals;
            }

            return false;
        }

    }
}
