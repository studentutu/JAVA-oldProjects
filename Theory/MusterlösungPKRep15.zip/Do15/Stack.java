package Do15;

/**
 * Created by Heraldo on 22.05.2015.
 */
public class Stack {

    private Node pointer;

    public boolean isEmpty() {return pointer == null;}

    public int size() {
        return isEmpty()? 0 : pointer.size();
    }

    public void push(Binary val) {
        if(val.getDecimal() == 0)
            return;

        pointer = new Node(val, pointer);
    }

    public Binary pop() {
        if(isEmpty())
            return null;

        Binary out = pointer.value;
        pointer = pointer.next;

        return out;
    }

    public Binary peek() {
        if(isEmpty())
            return null;

        return pointer.value;
    }

    @Override
    public boolean equals(Object o) {
        if(this == o)
            return true;

        if(o instanceof Stack) {
            Stack stack = (Stack) o;

            if(this.isEmpty() && stack.isEmpty())
                return true;

            if(this.size() != stack.size())
                return false;

            return this.isEmpty() || stack.isEmpty()? false : this.pointer.equals(stack.pointer);
        }

        return false;
    }

    @Override
    public String toString() {
        return isEmpty()? "Empty Stack" : pointer.string(size());
    }

    private class Node {
        private Node next;
        private Binary value;

        private Node(Binary val, Node next) {
            value = val;
            this.next = next;
        }

        private int size() {
            int size = 1;

            if(next != null)
                size += this.next.size();

            return size;
        }

        private boolean equals(final Node n) {
            boolean eq = this.value.equals(n.value);

            return this.next == null? eq : this.next.equals(n.next) && eq;
        }

        private String string(final int pos) {
            String output = String.format("%d. %s", pos, this.value.getValue());
            return output + "\n" + (this.next == null? "END" : this.next.string(pos - 1));
        }
    }
}
