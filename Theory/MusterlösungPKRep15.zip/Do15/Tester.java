package Do15;

public class Tester {
    public static final String ERROR = "\u001B[31m" + "ERROR: " + "\u001B[0m";
    public static final String OK = "\u001B[32m" + "OK" + "\u001B[0m";
    public static final String FAILED = "\u001B[33m" + "FAILED" + "\u001B[0m";

    public static void startTestingAll() {
        try {
            testBinary();
            testStack();
            testSearchTree();
        }
        catch (TesterException te) {
            System.out.println(String.format("%s\n  %s",FAILED, te.getMessage()));
        }
    }

    public static void startBinaryTest() {
        try {
            testBinary();
        }
        catch (TesterException te) {
            System.out.println(String.format("%s\n  %s",FAILED, te.getMessage()));
        }
    }

    public static void startStackTest() {
        try {
            testStack();
        }
        catch (TesterException te) {
            System.out.println(String.format("%s\n  %s",FAILED, te.getMessage()));
        }
    }

    public static void startTreeTest() {
        try {
            testSearchTree();
        }
        catch (TesterException te) {
            System.out.println(String.format("%s\n  %s",FAILED, te.getMessage()));
        }
    }

    private static void testBinary() throws TesterException {

        System.out.print(getMessage("Binary test"));

        Binary a = new Binary(38); // 010 0110
        Binary b = new Binary(2304); // 01001 0000 0000

        if(!a.getValue().equals("0100110") || !b.getValue().equals("0100100000000"))
            throw new TesterException(ERROR + "Wrong conversion from decimal to binary!");

        if(a.getDecimal() != 38 || b.getDecimal() != 2304)
            throw new TesterException(ERROR + "Wrong conversion from binary to decimal!");

        Binary e = new Binary(-4);
        if(e.getDecimal() != 0 || !e.getValue().equals("0"))
            throw new TesterException(ERROR + "Negative value not zero!");

        Binary c = a.addBinaries(b);
        Binary d = b.addBinaries(a);
        String result = "0100100100110";

        if(!c.getValue().equals(result) || !d.getValue().equals(result))
            throw new TesterException(ERROR + "Check implementation of addBinaries()!");

        if(c.getDecimal() != d.getDecimal() || d.getDecimal() != 2342)
            throw new TesterException(ERROR + "Check implementation of addBinaries()!");

        if(c.equals(b))
            throw new TesterException(ERROR + "Check implementation of equals()!");

        if(d.equals(null))
            throw new TesterException(ERROR + "Check implementation of equals()!");

        if(!c.equals(d))
            throw new TesterException(ERROR + "Check implementation of equals()!");

        System.out.println(OK);
    }

    private static void testStack() throws TesterException {

        System.out.print(getMessage("Stack test"));

        Stack stack = new Stack();

        if(!stack.isEmpty() || stack.size() != 0 || stack.peek() != null)
            throw new TesterException(ERROR + "By testing empty Stack. Check isEmpty(), size() or peek()!");

        stack.push(new Binary(5));
        stack.push(new Binary(3));
        stack.push(new Binary(45));
        Binary a = new Binary(312);
        stack.push(a);

        int size = stack.size();
        if(size != 4 || stack.isEmpty())
            throw new TesterException(ERROR + String.format("Wrong size after push()! Is: %d, Should be: 4", size));

        Binary tmp = stack.pop();
        if(!tmp.equals(a))
            throw new TesterException(ERROR + String.format("Wrong value at pop()!"));

        size = stack.size();
        if(size != 3)
            throw new TesterException(ERROR + String.format("Wrong size after pop()! Is: %d, Should be: 3", size));

        stack.push(new Binary(56));
        stack.push(new Binary(6));
        stack.push(new Binary(16));
        size = stack.size();
        if(size != 6)
            throw new TesterException(ERROR + String.format("Wrong size after push()! Is: %d, Should be: 6", size));

        stack.push(new Binary(-3));
        if(stack.peek().getDecimal() == 0)
            throw new TesterException(ERROR + String.format("Value smaller than 0 accepted!"));

        int limit = 100;
        for(int i = 0; i < limit; i++)
            stack.push(new Binary((int)(Math.random() * 400) + 1));

        size = stack.size();
        if(size != 106)
            throw new TesterException(ERROR + String.format("Wrong size after push()! Is: %d, Should be: 106", size));

        Stack stack1 = new Stack();
        for(int i = 0; i < size - 1; i++)
            stack1.push(new Binary((int)(Math.random() * 400) + 1));
        stack1.push(new Binary(500));

        if(stack1.equals(null))
            throw new TesterException(ERROR + "Check implementation of equals()!");

        if(stack.equals(stack1))
            throw new TesterException(ERROR + "Check implementation of equals()!");

        if(!stack1.equals(stack1))
            throw new TesterException(ERROR + "Check implementation of equals()!");

        for(int i = 0; i < size; i++) {
            stack.pop();
        }

        if(stack.pop() != null || !stack.isEmpty())
            throw new TesterException(ERROR + "Stack should be empty. Check implementation of pop()!");

        System.out.println(OK);
    }

    private static void testSearchTree() throws TesterException {
        System.out.print(getMessage("SearchTree test"));

        SearchTree tree = new SearchTree();

        if(!tree.isEmpty() || tree.size() != 0 || tree.height() != -1)
            throw new TesterException(ERROR + "By testing empty Stack. Check isEmpty(), size() or height()!");

        int[] values = {30, 20, 45, 10, 13, 25, 38, 50, 5, 22, 29, 12, 14};

        for(int v : values)
            tree.add(new Binary(v));

        int size = tree.size();
        if(size != 13 || tree.isEmpty())
            throw new TesterException(ERROR + String.format("Wrong size after push()! Is: %d, Should be: 13", size));

        int[] pos = {0, 4, 2, 6};
        Binary tmp = null;
        for (int p : pos) {
            tmp = new Binary(values[p]);
            if(!tree.contains(tmp))
                throw new TesterException(ERROR + String.format("Value not found. Check contains()!"));
        }

        tmp = new Binary(-4);
        tree.add(tmp);
        if(tree.contains(tmp))
            throw new TesterException(ERROR + String.format("Negative value found. Check contains()!"));

        int height = tree.height();
        if(tree.height() != 4)
            if(!tree.contains(tmp))
                throw new TesterException(ERROR + String.format("Wrong height! Is: %d, Should be: 4", height));

        if(!tree.equals(tree))
            throw new TesterException(ERROR + String.format("Check implementation of equals()!"));

        values = new int[]{30, 20, 45, 38, 50, 25, 22, 29};
        SearchTree sTree = new SearchTree();
        for(int v : values)
            sTree.add(new Binary(v));

        if(sTree.equals(tree))
            throw new TesterException(ERROR + String.format("Check implementation of equals()!"));

        System.out.println(OK);
    }

    private static String getMessage(String message) {
        int buffer = 25 - message.length();

        for(int i = 0; i < buffer; i++)
            message += ".";

        return message;
    }
}

class TesterException extends Exception {
    TesterException() { super(); }
    TesterException(String message) { super(message); }
}
