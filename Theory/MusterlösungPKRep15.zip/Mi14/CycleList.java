package Mi14;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Created by Heraldo on 26.05.2015.
 */
public class CycleList {

    private Node first;

    public boolean isEmpty() {return first == null;}

    public void add(Student s) {
        if(isEmpty()) {
            first = new Node(s, null);
            first.next = first;
        }
        else {
            if(contains(s))
                return;

            Node n = first;

            while(n.next != first)
                n = n.next;

            n.next = new Node(s, first);
        }

    }

    public int size() {
        if(isEmpty())
            return 0;

        int size = 0;
        Node n = first;

        do {
            size++;
            n = n.next;
        }while(n != first);

        return size;
    }

    public boolean contains(Student s) {
        if(isEmpty())
            return false;

        Node n = first;
        do {
            if(n.value.equals(s))
                return true;

            n = n.next;
        }while(n != first);

        return false;
    }

    public Student getValueByKey(int key) {
        if(isEmpty())
            return null;

        Node n = first;

        do {
            if(n.value.getMatrNr() == key)
                return n.value;

            n = n.next;
        }while(n != first);

        return null;
    }

    public Student getValueAtIndex(int index) {
        if(isEmpty() || index >= size() || index < 0)
            return null;

        Node n = first;

        while(index > 0) {
            n = n.next;
            index--;
        }

        return n.value;
    }

    public CycleList getValueByName(String name) {
        CycleList list = new CycleList();

        if(!isEmpty()) {
            Node n = first;

            do {
                if (n.value.getName().equals(name))
                    list.add(n.value);

                n = n.next;
            } while(n != first);
        }

        return list;
    }

    public boolean equals(Object o) {
        if(o == null)
            return false;

        if(o instanceof CycleList) {
            CycleList that = (CycleList) o;

            if(this.size() != that.size())
                return false;

            Node n = this.first;
            Node tmp = that.first;

            do {
                if(!n.value.equals(tmp.value))
                    return false;

                n = n.next;
                tmp = tmp.next;
            } while(n != first);

            return true;
        }

        return false;
    }

    public void addToList(List<Student> list) {
        if(isEmpty())
            return;

        Node n = first;

        do {
            list.add(n.value);
            n = n.next;
        } while(n != first);

    }

    public Iterator<Student> iterator() {
        ArrayList<Student> list = new ArrayList<Student>();
        addToList(list);

        return list.iterator();
    }

    private class Node {
        private Student value;
        private Node next;

        private Node(Student val, Node next) {
            this.value = val;
            this.next = next;
        }
    }
}
