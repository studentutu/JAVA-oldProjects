package Mi14;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

/**
 * Created by Heraldo on 22.05.2015.
 */
public class HashTable {

    private CycleList[] table;
    private final int m;

    public HashTable(int m) {
        this.m = m;
        table = new CycleList[this.m];
    }

    public boolean isEmpty() {

        for(CycleList n : table) {
            if(n != null)
                return false;
        }

        return true;
    }

    public int size() {
        int size = 0;

        for(CycleList n : table) {
            if(n != null)
                size += n.size();
        }

        return size;
    }

    public int insert(int key, Student s) {
        if(s == null)
            return -1;

        int tmp = hash(key);

        if(table[tmp] == null)
            table[tmp] = new CycleList();

        table[tmp].add(s);

        return tmp;
    }

    public Student get(int key) {
        return table[hash(key)] == null? null : table[hash(key)].getValueByKey(key);
    }

    public CycleList getList(int index) {
        return table[index];
    }

    public int[][] toKeyDoubleArray() {
        int[][] output = new int[table.length][];
        int row = 0;

        for(CycleList l : table) {
            if(l != null) {
                output[row] = new int[l.size()];
                int column = 0;

                for (Iterator<Student> iter = l.iterator(); iter.hasNext(); )
                    output[row][column++] = iter.next().getMatrNr();
            }
            else {
                output[row] = new int[0];
            }

            row++;
        }

        return output;
    }

    public boolean equals(Object o) {
        if(o instanceof HashTable) {
            HashTable that = (HashTable) o;

            if(this.size() != that.size())
                return false;

            CycleList list = null;
            for(int i = 0; i < m; i++) {
                list = this.getList(i);

                if(list == null)
                    continue;

                else if(!this.getList(i).equals(that.getList(i)))
                    return false;
            }

            return true;
        }

        return false;
    }

    public String toString() {
        int[][] tab = toKeyDoubleArray();
        String output = "";

        for(int i = 0; i < m; i++) {
            output += "Index " + i + " : ";

            if(tab[i] == null)
                output += "No Keys";
            else {
                for (int j = 0; j < tab[i].length; j++)
                    output += tab[i][j] + ";";
            }

            output += "\n";
        }

        return output;
    }

    public List<Student> toList() {
        List<Student> list = new ArrayList<Student>();

        for(CycleList tmp : table) {
            if(tmp != null)
                tmp.addToList(list);
        }

        return list;
    }

    public HashMap<Integer, Student> toHashMap() {
        List<Student> list = toList();
        HashMap<Integer, Student> map = new HashMap<Integer, Student>();

        for(Student s : list) {
            map.put(s.getMatrNr(), s);
        }

        return map;
    }

    private int hash(int key) {
        int tmp = 0;

        while(key > 0) {
            tmp += key % 10;
            key /= 10;
        }

        return tmp % m;
    }


}
