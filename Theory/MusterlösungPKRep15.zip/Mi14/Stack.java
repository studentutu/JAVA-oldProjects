package Mi14;

/**
 * Created by Heraldo on 25.05.2015.
 */
public class Stack {

    private int[] storage;
    private int capacity;
    private int pointer;

    public Stack(int cap) {
        storage = new int[cap];
        capacity = cap;
        pointer = 0;
    }

    public int size() {
        return pointer;
    }

    public boolean isEmpty() {
        return size() == 0;
    }

    public int getMaxCapacity() { return storage.length; }

    public void push(int val) {
        if(val < 0)
            return;

        if(pointer == storage.length)
            arrangeStorage(capacity);

        storage[pointer++] = val;
    }

    public int pop() {
        if(isEmpty())
            return -1;

        int out = storage[--pointer];
        storage[pointer] = 0;

        if(pointer < storage.length - capacity)
            arrangeStorage(-capacity);

        return out;
    }

    public int peek() {
        return isEmpty()? -1 : storage[pointer - 1];
    }

    public String toString() {
        String out = "";

        for(int i = 0; i < pointer; i++)
            out += storage[i] + ",";

        return out;
    }

    private void arrangeStorage(int cap) {
        int[] newArray = new int[storage.length + cap];
        int limit = newArray.length < storage.length? newArray.length : storage.length;

        for(int i = 0; i < limit; i++)
            newArray[i] = storage[i];

        storage = newArray;
    }
}
