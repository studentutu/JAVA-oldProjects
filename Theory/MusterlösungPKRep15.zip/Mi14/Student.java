package Mi14;

/**
 * Created by Heraldo on 22.05.2015.
 */
public class Student {

    private static int _COUNTER = 1500000;
    private final int matrNr;
    private final String name;
    private int semester;

    public Student(String name, int semester) {
        _COUNTER += (Math.random() * 100) + 100;
        matrNr = _COUNTER;
        this.name = name;
        this.semester = semester;
    }

    public int getMatrNr() {
        return matrNr;
    }

    public int getSemester() { return semester; }

    public String getName() { return name; }

    public void incSemester() { semester++; }

    @Override
    public String toString() { return String.format("%s; %d; %d", name, matrNr, semester); }

    @Override
    public boolean equals(Object o) {
        if(o == null)
            return false;

        if(o instanceof Student) {
            Student that = (Student) o;

            return this.matrNr == that.matrNr && this.semester == that.semester && this.name.equals(that.name);
        }

        return false;
    }
}
