package Mi14;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;


public class Tester {

    public static final String ERROR = "\u001B[31m" + "ERROR: " + "\u001B[0m";
    public static final String OK = "\u001B[32m" + "OK" + "\u001B[0m";
    public static final String FAILED = "\u001B[33m" + "FAILED" + "\u001B[0m";

    public static void startTestingAll() {

        try {
            testStudent();
            testStack();
            testList();
            testHash();
        }
        catch(TesterException te) {
            System.out.print(FAILED + "\n   " + te.getMessage());
        }

    }

    public static void startStudentTest() {
        try {
            testStudent();
        }
        catch(TesterException te) {
            System.out.print(FAILED + "\n   " + te.getMessage());
        }
    }

    public static void startStackTest() {
        try {
            testStack();
        }
        catch(TesterException te) {
            System.out.print(FAILED + "\n   " + te.getMessage());
        }
    }

    public static void startListTest() {
        try {
            testList();
        }
        catch(TesterException te) {
            System.out.print(FAILED + "\n   " + te.getMessage());
        }
    }

    public static void startTableTest() {
        try {
            testHash();
        }
        catch(TesterException te) {
            System.out.print(FAILED + "\n   " + te.getMessage());
        }
    }

    private static void testStudent() throws TesterException {
        System.out.print(getMessage("Student test"));

        Student a = new Student("Michael", 4);
        Student b = new Student("Michael", 5);

        if(a.getMatrNr() < b.getMatrNr() && b.getMatrNr() < 1500000)
            throw new TesterException(ERROR + "MatrNr are smaller than 1500000!");

        if(a.getMatrNr() == b.getMatrNr())
            throw new TesterException(ERROR + "Different Students with same MatrNr!");

        a.incSemester();
        if(a.getSemester() != b.getSemester())
            throw new TesterException(ERROR + "Check incSemester() or getSemester()!");

        if(a.getName() == null)
            throw new TesterException(ERROR + "Check Student name!");

        if(a.equals(null))
            throw new TesterException(ERROR + "Student equals NULL!");

        if(a.equals(b))
            throw new TesterException(ERROR + "Different Students are equal!");

        if(!a.equals(a))
            throw new TesterException(ERROR + "Check equals()!");

        System.out.println(OK);
    }

    private static void testStack() throws TesterException {
        System.out.print(getMessage("Stack test"));

        Stack stack = new Stack(5);

        if(!stack.isEmpty() || stack.size() != 0 || stack.pop() != -1)
            throw new TesterException(ERROR + "By testing empty Stack. Check isEmpty(), size() or pop()!");

        if(stack.getMaxCapacity() != 5)
            throw new TesterException(ERROR + "Wrong initial Stack max capacity!");

        stack.push(5);
        stack.push(3);
        stack.push(45);
        stack.push(7);

        if(stack.size() != 4)
            throw new TesterException(ERROR + String.format("Wrong size after push()! Is: %d, Should be: 4", stack.size()));

        int tmp = stack.pop();
        if(tmp != 7)
            throw new TesterException(ERROR + String.format("Wrong value at pop()! Is: %d, Should be: 7", tmp));

        if(stack.size() != 3)
            throw new TesterException(ERROR + String.format("Wrong size after pop()! Is: %d, Should be: 3", stack.size()));

        tmp = stack.getMaxCapacity();
        if(tmp != 5)
            throw new TesterException(ERROR + String.format("Wrong capacity after pop()! Is: %d, Should be: 5", tmp));

        stack.push(56);
        stack.push(6);
        stack.push(16);

        if(stack.size() != 6)
            throw new TesterException(ERROR + String.format("Wrong size after push()! Is: %d, Should be: 6", stack.size()));

        tmp = stack.getMaxCapacity();
        if(tmp != 10)
            throw new TesterException(ERROR + String.format("Wrong capacity after push()! Is: %d, Should be: 10", tmp));

        stack.push(-3);
        if(stack.peek() == -3)
            throw new TesterException(ERROR + String.format("Negative value accepted!"));

        Random r = new Random();
        for(int i = 0; i < 11; i++) {
            tmp = r.nextInt();
            stack.push(tmp < 0? -tmp : tmp);
        }

        if(stack.size() != 17)
            throw new TesterException(ERROR + String.format("Wrong size after push()! Is: %d, Should be: 17", stack.size()));

        tmp = stack.getMaxCapacity();
        if(tmp != 20)
            throw new TesterException(ERROR + String.format("Wrong capacity after push()! Is: %d, Should be: 20", tmp));

        stack.pop();
        stack.pop();
        stack.pop();

        tmp = stack.getMaxCapacity();
        if(tmp != 15)
            throw new TesterException(ERROR + String.format("Wrong capacity after pop()! Is: %d, Should be: 15", tmp));

        System.out.println(OK);
    }

    private static void testList() throws TesterException {
        System.out.print(getMessage("CycleList test"));

        CycleList list = new CycleList();

        if(!list.isEmpty() || list.size() != 0 || list.contains(null))
            throw new TesterException(ERROR + "By testing empty list!");

        List<Student> gList = getListWithStudents(23);

        for(Iterator<Student> iter = gList.iterator(); iter.hasNext();) {
            list.add(iter.next());
        }

        int tmp = gList.size();
        if(list.isEmpty() || list.size() != tmp)
            throw new TesterException(ERROR + String.format("Wrong List size! Is: %d, Should be: %d", list.size(), tmp));

        Student s = list.getValueAtIndex(2);
        list.add(s);
        int lastIndex = list.size() - 1;
        if(list.getValueAtIndex(lastIndex).equals(s))
            throw new TesterException(ERROR + "At least two entries for same Student!");

        tmp = (int)(Math.random() * tmp);
        s = gList.get(tmp);
        if(!list.contains(s))
            throw new TesterException(ERROR + String.format("Student not found!"));

        if(!list.getValueByKey(s.getMatrNr()).equals(s))
            throw new TesterException(ERROR + String.format("Check implementation of getValueByKey()!"));

        if(!list.getValueAtIndex(tmp).equals(s))
            throw new TesterException(ERROR + String.format("Check implementation of getValueAtIndex()!"));

        List<Student> nameList = new ArrayList<Student>();
        String nameToLookFor = s.getName();
        for(Iterator<Student> iter = gList.iterator(); iter.hasNext();) {
            s = iter.next();
            if(s.getName().equals(nameToLookFor))
                nameList.add(s);
        }

        CycleList neoList = list.getValueByName(nameToLookFor);

        if(neoList.size() != nameList.size()) {
            String format = "Wrong number of Students with same name! Is: %d, Should be: %d!";
            throw new TesterException(ERROR + String.format(format, neoList.size(), nameList.size()));
        }

        for(Student t : nameList) {
            if(!neoList.contains(t))
                throw new TesterException(ERROR + "At least one Student with same name not found!");
        }

        neoList = new CycleList();

        for(Student t : gList)
            neoList.add(t);

        if(!list.equals(neoList))
            throw new TesterException(ERROR + "Check implementation of equals!");

        System.out.println(OK);
    }

    private static void testHash() throws TesterException {
        System.out.print(getMessage("HashTable test"));

        int m = 13;
        HashTable table = new HashTable(m);

        if(!table.isEmpty() || table.size() != 0)
            throw new TesterException(ERROR + "By testing empty table. Check isEmpty() or size()!");

        List<Student> gList = getListWithStudents(30);
        int hash = -1;
        for(Student s : gList) {
            hash = hash(s.getMatrNr(), m);
            if(hash != table.insert(s.getMatrNr(), s))
                throw new TesterException(ERROR + "Wrong hash value!");
        }

        if(table.isEmpty())
            throw new TesterException(ERROR + "Table is empty!");

        int size = table.size();
        if(size != gList.size())
            throw new TesterException(ERROR + "Wrong table size!");

        Student tmp = gList.get((int)(Math.random() * 30));
        table.insert(tmp.getMatrNr(), tmp);
        if(table.size() != size)
            throw new TesterException(ERROR + "At least two entries for same Student!");

        if(!table.get(tmp.getMatrNr()).equals(tmp))
            throw new TesterException(ERROR + "At least one Student not found. Check implementation of get()!");

        List<Student> newList = new ArrayList<Student>();
        for(Student s : gList) {
            if(hash(s.getMatrNr(), m) == hash)
                newList.add(s);
        }

        CycleList list = table.getList(hash);
        if(list.size() != newList.size())
            throw new TesterException(ERROR + String.format("Wrong list size. Check getList()!"));

        for(Student s : newList) {
            if(!list.contains(s))
                throw new TesterException(ERROR + "At least one Student missing. Check getList()!");
        }

        if(!table.equals(table))
            throw new TesterException(ERROR + "Check implementation of equals()!");

        int[][] doubleArr = table.toKeyDoubleArray();
        if(doubleArr.length != m)
            throw new TesterException(ERROR + "Wrong number of rows. Check toKeyDoubleArray()!");

        for(int i = 0; i < m; i++) {

            list = table.getList(i);

            if(list == null && doubleArr[i].length != 0)
                throw new TesterException(ERROR + "Wrong number of columns. Check toKeyDoubleArray()!");

            if(list != null) {
                if (doubleArr[i].length != list.size())
                    throw new TesterException(ERROR + "Wrong number of columns. Check toKeyDoubleArray()!");

                size = list.size();
                for (int j = 0; j < size; j++) {
                    if (doubleArr[i][j] != list.getValueAtIndex(j).getMatrNr())
                        throw new TesterException(ERROR + "Wrong values. Check toKeyDoubleArray()!");
                }
            }
        }

        System.out.println(OK);
    }

    private static String getMessage(String message) {
        int buffer = 25 - message.length();

        for(int i = 0; i < buffer; i++)
            message += ".";

        return message;
    }

    private static int hash(int key, int m) {
        int tmp = 0;

        while(key > 0) {
            tmp += key % 10;
            key /= 10;
        }

        return tmp % m;
    }

    private static List<Student> getListWithStudents(int size) {
        List<Student> gList = new ArrayList<Student>();

        for(int i = size; i > 0; i--) {
            char name = (char)((Math.random() * 25) + 65);
            gList.add(new Student(String.valueOf(name), (int)(Math.random() * 5) + 1));
        }

        return gList;
    }
}

class TesterException extends Exception {
    TesterException() { super(); }
    TesterException(String message) { super(message); }
}
