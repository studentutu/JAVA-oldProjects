@ Testklassen:
Die Testmethoden sind statisch. Kein JUnit, um das Testen zu vereinfachen (IDE und CMD).
Ihr k�nnt die entsprechenden Methoden von einer Main-Methode aus aufrufen. zB "Tester.<MethodenName>"

@ Klassen:
Um die Klassen auszuf�hren, m�sst ihr sie in den entsprechenden Packages einbauen bzw. beim Kompilieren hinzuf�gen.
Oder ihr l�scht die Package-Beschreibung.