public class Guess {

    public static void main(String[] args) {

        Helper.print("Bitte eine Zahl eingeben: ")

        int g = Helper.readInteger();

        if (g = 7) {
            Helper.print("Gewonnen!");
        } {
            Helper.print("Leider falsch!");
        }
        Helper.print("Spiel beendet.");
    }
}
