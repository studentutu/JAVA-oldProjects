public class Helper {

    private static java.util.Scanner sc = null;

    public static void print(String s) {
        System.out.println(s);
    }

    public static void print(int i) {
        System.out.println(i);
    }

    public static void print(double d) {
        System.out.println(d);
    }

    public static int readInteger() {
        if (null == sc) {
            sc = new java.util.Scanner(System.in);
        }
        return sc.nextInt();
    }
}
